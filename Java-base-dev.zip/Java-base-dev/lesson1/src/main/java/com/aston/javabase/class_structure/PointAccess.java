package com.aston.javabase.class_structure;

public class PointAccess {

    public static void main(String[] args) {

        Dog dog = new Dog("MyDogName");
        dog.eat();
        dog.printDogName();
        dog.printAnimalName();
    }
}
