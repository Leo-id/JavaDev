package com.aston.javabase.cycles;

public class DoWhileExample {

    public static void main(String[] args) {

        int count = 1;

        do {
            System.out.println("count = " + count);
            count ++;
        } while (count < 11);
    }
}


//count = 1
//count = 2
//count = 3
//count = 4
//count = 5
//count = 6
//count = 7
//count = 8
//count = 9
//count = 10
