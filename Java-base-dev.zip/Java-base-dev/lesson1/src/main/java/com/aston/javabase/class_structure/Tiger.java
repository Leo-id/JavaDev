package com.aston.javabase.class_structure;

//public class Tiger extends Cat {
public class Tiger {
    // нет конструктора
}
