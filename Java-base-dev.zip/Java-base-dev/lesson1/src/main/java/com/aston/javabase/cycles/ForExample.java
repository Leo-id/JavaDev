package com.aston.javabase.cycles;

public class ForExample {

    public static void main(String[] args) {

        for (int i = 1; i < 6; i++) {
            System.out.println("Строка №" + i);
        }
    }
}

//Строка №1
//Строка №2
//Строка №3
//Строка №4
//Строка №5
